<?php
if (isset($_POST['Visitor_registration'])) {
    require "./connection/connect.inc.php";

    $Fname = $_POST['CustFname'];
    $Lname = $_POST['CustLname'];
    $Email = $_POST['CustEmail'];
    $DOB = $_POST['CustDOB'];
    $Vdate=$_POST['visit_date'];

    if (empty($Fname) || empty($Lname) || empty($Vdate)|| empty($DOB)|| empty($Vdate)) {
        header("location:VisitorRegistration.php?error=emptyfields&CustID="  . "&CustFname=" . $Fname . "&CustLname=" . $Lname . "&CustDOB=" . $DOB. "&CustDOB=" . $Vdate);
        exit();
    } else {
        $sql = "SELECT CustID FROM customer WHERE CustID=?";
        if (isset($conn)) {
            $stmt = mysqli_stmt_init($conn);
        }
        if (!mysqli_prepare($stmt, $sql)) {
            header("location:VisitorRegistration.php?error=sqlerror");
            exit();
        } else {
            mysqli_stmt_bind_param($stmt, "s", $CustId);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
            $resultcheck = mysqli_stmt_num_rows($stmt);
            if ($resultcheck > 0) {
                header("Location:VisitorRegistration.php?error=usertaken");
                exit();
            } else {
                $sql = "INSERT INTO customer (CustID,CustFname,CustLname,CustEmail,CustDOB,visit_date) VALUES(?,?,?,?,?)";
                $stmt = mysqli_stmt_init($conn);
                if (!mysqli_prepare($stmt, $sql)) {
                    header("location:VisitorRegistration.php?error=sqlerror");
                    exit();
                } else {
                    mysqli_stmt_bind_param($stmt, "ssss", $CustId, $Fname, $Lname, $DOB,$Vdate);
                    mysqli_stmt_execute($stmt);
                    header("location:VisitorRegistration.php?error=success");
                    exit();
                }
            }
        }
    }
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
} else {
    header("location:VisitorRegistration.php?");
    exit();
}
