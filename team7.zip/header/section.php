<section>
    <!-- Start WOWSlider.com BODY section -->
    <div id="wowslider-container1">
        <div class="ws_images">
            <ul>
                <li><a href="#"><img src="./Images/exhibi.jpg"
                                     alt="Animal Exhibitions" title="Animal Exhibitions " id="wows1_0"/></a></li>
                <li><img src="./Images/elephants.jpg" alt="safe tour"
                         title="safe tour" id="wows1_1"/></li>
                <li><a href="#"><img src="./Images/restaurant.jpg"
                                     alt="bootstrap image slider" title="Restaurants " id="wows1_2"/></a></li>
                <li><img src="./Images/ticket.jpg" alt="ATm"
                         title="Buy ticket" id="wows1_3"/></li>
            </ul>
        </div>

        <div class="ws_shadow"></div>
    </div>
    <script type="text/javascript" src="./Javascript/engine1/wowslider.js"></script>
    <script type="text/javascript" src="./Javascript/engine1/script.js"></script>
    <!-- End WOWSlider.com BODY section -->
</section>
