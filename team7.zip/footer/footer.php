<div class="footerin">

    <p> <h6>About:</h6>
    company<br>
    team<br>
    carrier

    </p>

</div>
<div class="footerin">
    <p> <h6>Support:</h6>
    Help<br>
    ticket help
</div>
<div class="footerin">
    <p> <h6>Legal:</h6>
    Term<br>
    privacy<br>
    All right reserved &copy;

    </p>

</div>
